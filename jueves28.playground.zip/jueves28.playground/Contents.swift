import UIKit
//1
let num1: Int = 7
let num2: Int = 11
let sumaa: Int = num1 + num2
print(sumaa)
let multiplicacion: Int  = num1 * num2
print(multiplicacion)
let division: Int = num1/num2
print(division)

//2
var numeros : [Int] = [4,2,6,8,10]

//3

let cantidadnumeros = numeros.count


//4
var numerosDesordenados = [6,2,3,7]
let numerosOrdenados = numerosDesordenados.sorted()

//5
numeros.append (3)
numeros.append (5)

//6
numeros.remove (at:2)

//7

let a=4
let b=3
if( a>b){
    
}

//8

let edad =  19
edad>21

//9

let numero1 = 3
let numero2 = -4
if numero2>0{
    
}
else if numero2<0{
    
}

else {
    
}

//10
let clima = "soleado"
switch clima{
case "Soleado":
    print("El clima es agradable")
case "Nublado", "Lloviendo":
    print("El clima esta feo")
default:
    print("Algo salio mal")
}
    



    






